#include "historico.h"
#include "ui_historico.h"
#include <QtCharts>
#include <QMessageBox>
#include <QTimer>

historico::historico(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::historico)
    ,graficoPH(new QChart())
    ,graficoViewPH(new QChartView(graficoPH))
    ,graficoTEMP(new QChart())
    ,graficoViewTEMP(new QChartView(graficoTEMP))
    ,graficoTDS(new QChart())
    ,graficoViewTDS(new QChartView(graficoTDS))
    ,seriePH(new QLineSeries())
    ,serieTEMP(new QLineSeries())
    ,serieTDS(new QLineSeries())
    ,timer(new QTimer(this))

{
    ui->setupUi(this);

    //grafico de ph
    graficoPH -> addSeries(seriePH);
    graficoPH -> setTitle("pH del agua");
    graficoPH -> createDefaultAxes();
    graficoPH -> axes(Qt::Horizontal).first() -> setTitleText("Tiempo");
    graficoPH -> axes(Qt::Vertical).first() -> setTitleText("pH");
    QVBoxLayout *layoutPH = new QVBoxLayout( ui -> graficoPH);
    layoutPH -> addWidget(graficoViewPH);
    ui->graficoPH->setLayout(layoutPH);


    //grafico de temperatura
    graficoTEMP -> addSeries(serieTEMP);
    graficoTEMP -> setTitle("Temperatura del agua");
    graficoTEMP -> createDefaultAxes();
    graficoTEMP -> axes(Qt::Horizontal).first() -> setTitleText("Tiempo");
    graficoTEMP -> axes(Qt::Vertical).first() -> setTitleText("Temperatura [°C]");
    QVBoxLayout *layoutTEMP = new QVBoxLayout(ui -> graficoTEMP);
    layoutTEMP -> addWidget(graficoViewTEMP);
    ui->graficoTEMP->setLayout(layoutTEMP);

    //grafico TDS
    graficoTDS -> addSeries((serieTDS));
    graficoTDS -> setTitle("TDS (Solidos Totales Disueltos)");
    graficoTDS -> createDefaultAxes();
    graficoTDS -> axes(Qt::Horizontal).first() -> setTitleText("Tiempo");
    graficoTDS -> axes(Qt::Vertical).first() -> setTitleText("TDS");
    QVBoxLayout *layoutTDS =new QVBoxLayout(ui -> graficoTDS);
    layoutTDS -> addWidget(graficoViewTDS);
    ui->graficoTDS->setLayout(layoutTDS);


    connect(timer,&QTimer::timeout, this , &historico::updateData);
    timer -> start(1000);
    setupConnections();
}

historico::~historico()
{
    delete ui;
}

void historico::setupConnections()
{
    connect(ui->Bactual, &QPushButton::clicked, this, [this]() { emit goToActual(); });
    connect(ui->Balarma, &QPushButton::clicked, this, [this]() { emit goToAlarma(); });
    connect(ui->Bmenu, &QPushButton::clicked, this, [this]() { emit goToMenu(); });
    connect(ui->Bvolver, &QPushButton::clicked, this, [this]() { emit goToMenu(); });
}

void historico::updateData()
{
    static int time = 0;
    double ValorPH = 6.5 + (rand() % 201) / 100.0;
    double ValorTEMP = 7 + (rand() % 1201) / 100.0;
    double ValorTDS = 750 + (rand() % 601);
    checkLimits("pH", ValorPH, 6.5, 8.5);
    checkLimits("Temperatura", ValorTEMP, 7, 18);
    checkLimits("TDS", ValorTDS, 750, 1350);
    seriePH->append(time, ValorPH);
    serieTEMP->append(time, ValorTEMP);
    serieTDS->append(time, ValorTDS);
    int windowSize = 10;
    graficoPH->axes(Qt::Horizontal).first()->setRange(time - windowSize, time);
    graficoTEMP->axes(Qt::Horizontal).first()->setRange(time - windowSize, time);
    graficoTDS->axes(Qt::Horizontal).first()->setRange(time - windowSize, time);
    double minPH = seriePH->at(0).y();
    double maxPH = seriePH->at(0).y();
    double minTEMP = serieTEMP->at(0).y();
    double maxTEMP = serieTEMP->at(0).y();
    double minTDS = serieTDS->at(0).y();
    double maxTDS = serieTDS->at(0).y();
    for (int i = 1; i < seriePH->count(); ++i) {
        minPH = std::min(minPH, seriePH->at(i).y());
        maxPH = std::max(maxPH, seriePH->at(i).y());
    }
    for (int i = 1; i < serieTEMP->count(); ++i) {
        minTEMP = std::min(minTEMP, serieTEMP->at(i).y());
        maxTEMP = std::max(maxTEMP, serieTEMP->at(i).y());
    }
    for (int i = 1; i < serieTDS->count(); ++i) {
        minTDS = std::min(minTDS, serieTDS->at(i).y());
        maxTDS = std::max(maxTDS, serieTDS->at(i).y());
    }
    graficoPH->axes(Qt::Vertical).first()->setRange(minPH - 0.5, maxPH + 0.5);
    graficoTEMP->axes(Qt::Vertical).first()->setRange(minTEMP - 1, maxTEMP + 1);
    graficoTDS->axes(Qt::Vertical).first()->setRange(minTDS - 20, maxTDS + 20);
    time++;
}
void historico::checkLimits(const QString &parameter, double value , double bajo , double sobre)
{
    if (value < bajo || value > sobre) {
        QMessageBox::warning(this, "Advertencia", QString("El valor de %1 está fuera de rango: %2").arg(parameter).arg(value));
    }
}

#ifndef HISTORICO_H
#define HISTORICO_H
#include <QtCharts>
namespace Ui {
class historico;
}

class historico : public QMainWindow
{
    Q_OBJECT

public:
    explicit historico(QWidget *parent = nullptr);
    ~historico();

signals:
    void goToAlarma();
    void goToActual();
    void goToMenu();
public slots:
    void updateData();

private:
    Ui::historico *ui;
    QChart *graficoPH; QChartView *graficoViewPH;
    QChart *graficoTEMP;QChartView *graficoViewTEMP;
    QChart *graficoTDS;QChartView *graficoViewTDS;
    QLineSeries *seriePH;
    QLineSeries *serieTEMP;
    QLineSeries *serieTDS;

    QTimer *timer;
    void initGraphs();
    void setupConnections();
    void checkLimits(const QString &parameter, double value, double bajo , double sobre);
};


    void setupConnections();


#endif // HISTORICO_H
